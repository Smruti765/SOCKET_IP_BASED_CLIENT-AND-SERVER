﻿namespace server
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.normal = new System.Windows.Forms.Button();
            this.title = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtServerLog = new System.Windows.Forms.TextBox();
            this.txtServerMessage = new System.Windows.Forms.TextBox();
            this.btnSendServer = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // normal
            // 
            this.normal.BackColor = System.Drawing.Color.Silver;
            this.normal.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.normal.Location = new System.Drawing.Point(50, 181);
            this.normal.Name = "normal";
            this.normal.Size = new System.Drawing.Size(228, 31);
            this.normal.TabIndex = 20;
            this.normal.Text = "Type Text";
            this.normal.UseVisualStyleBackColor = false;
            this.normal.Click += new System.EventHandler(this.normal_Click);
            // 
            // title
            // 
            this.title.BackColor = System.Drawing.Color.Silver;
            this.title.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.title.Location = new System.Drawing.Point(62, 11);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(591, 45);
            this.title.TabIndex = 19;
            this.title.Text = "SERVER SOCKET";
            this.title.UseVisualStyleBackColor = false;
            this.title.Click += new System.EventHandler(this.title_Click);
            // 
            // btnStop
            // 
            this.btnStop.BackColor = System.Drawing.Color.Silver;
            this.btnStop.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStop.Location = new System.Drawing.Point(174, 98);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(162, 44);
            this.btnStop.TabIndex = 18;
            this.btnStop.Text = "Stop Server";
            this.btnStop.UseVisualStyleBackColor = false;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Silver;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(517, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 24);
            this.label1.TabIndex = 17;
            this.label1.Text = "Message Log";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtServerLog
            // 
            this.txtServerLog.Location = new System.Drawing.Point(359, 99);
            this.txtServerLog.Multiline = true;
            this.txtServerLog.Name = "txtServerLog";
            this.txtServerLog.ReadOnly = true;
            this.txtServerLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtServerLog.Size = new System.Drawing.Size(456, 341);
            this.txtServerLog.TabIndex = 16;
            this.txtServerLog.TextChanged += new System.EventHandler(this.txtServerLog_TextChanged);
            // 
            // txtServerMessage
            // 
            this.txtServerMessage.Location = new System.Drawing.Point(12, 232);
            this.txtServerMessage.Name = "txtServerMessage";
            this.txtServerMessage.Size = new System.Drawing.Size(339, 22);
            this.txtServerMessage.TabIndex = 15;
            this.txtServerMessage.TextChanged += new System.EventHandler(this.txtServerMessage_TextChanged);
            // 
            // btnSendServer
            // 
            this.btnSendServer.BackColor = System.Drawing.Color.Silver;
            this.btnSendServer.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSendServer.Location = new System.Drawing.Point(107, 277);
            this.btnSendServer.Name = "btnSendServer";
            this.btnSendServer.Size = new System.Drawing.Size(113, 39);
            this.btnSendServer.TabIndex = 14;
            this.btnSendServer.Text = "Send";
            this.btnSendServer.UseVisualStyleBackColor = false;
            this.btnSendServer.Click += new System.EventHandler(this.btnSendServer_Click);
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.Silver;
            this.btnStart.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.Location = new System.Drawing.Point(6, 99);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(162, 44);
            this.btnStart.TabIndex = 13;
            this.btnStart.Text = "Start Server";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.normal);
            this.Controls.Add(this.title);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtServerLog);
            this.Controls.Add(this.txtServerMessage);
            this.Controls.Add(this.btnSendServer);
            this.Controls.Add(this.btnStart);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button normal;
        private System.Windows.Forms.Button title;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtServerLog;
        private System.Windows.Forms.TextBox txtServerMessage;
        private System.Windows.Forms.Button btnSendServer;
        private System.Windows.Forms.Button btnStart;
    }
}

